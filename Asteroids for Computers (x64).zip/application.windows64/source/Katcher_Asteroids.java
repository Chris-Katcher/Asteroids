import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Katcher_Asteroids extends PApplet {



Ship ship;
InputManager input;
Asteroid_Manager astManager;
CollisionManager manageCollisions;
Bullet_Manager bul;
Menu menu;

ArrayList<Asteroid> asteroids;
ArrayList<Bullet> bullets;

boolean shoot;

PImage background;

AudioPlayer player;
Minim minim;

int mode;
int level = 5;
int score;

public void setup() 
{
  
  background = loadImage("background.png");
  manageCollisions = new CollisionManager(); //<>//
  ship = new Ship();
  astManager = new Asteroid_Manager();
  input = new InputManager();
  bul = new Bullet_Manager();
  menu = new Menu();
  minim = new Minim(this);
  player = minim.loadFile("tracnee_16bit.wav");
  player.setGain(-15);
  player.play();
  player.loop();
  
}

public void draw()
{
  if(menu.Display())
  {
    background(0);
    tint(255,255,255);
    image(background, width/2 ,height/2);
    astManager.DrawAsteroids();
    astManager.DrawSmallAsteroids();
    bul.DrawBullets();
    manageCollisions.HandleShipCollisions();
    manageCollisions.HandleBulletCollisions();
    manageCollisions.HandleSmallAsteroidCollisions();
    manageCollisions.HandleSmallBulletCollisions();
     
    if ( astManager.asteroids.size() == 0 && 
         astManager.smallAsteroids.size() == 0 )
    {
      manageCollisions = new CollisionManager();
      astManager = new Asteroid_Manager();
      astManager.InitializeMode(mode);
      level++;
    }
    ship.Update();
    ship.Wrap();
    ship.Display();
    text(score, 100, 50);
  } 
}

public void keyPressed()
{
  if ( key == ESC && !menu.main.display)
  {
    menu.pause.Pause();
    key = 0;
  }
  input.recordKeyPress(keyCode);
  ship.Turn();
  bul.UpdateBullets();
}

public void keyReleased()
{
  input.recordKeyRelease(keyCode);
  ship.Deccelerate();
  ship.StopTurning();
  bul.UpdateBullets();
}

public void mouseClicked()
{
  menu.HandleMouseClick();
}
class Asteroid {
  
  PVector position;
  PVector direction;
  PVector velocity;
  float radius;
  int randomAst;
  boolean colliding;
  boolean destroyed;
  String imgName;
  PImage img;
  int mass;
  int asteroid_depth;
  int difficulty;
  Asteroid (int dif)
  {
    // Instantiate vectors and fields
    this.position = new PVector ( (int)random(0, width), (int)random(0, height) );
    while(position.x < (ship.position.x+200) && position.x > (ship.position.x-200)
        && position.y < (ship.position.y+200) && position.y > (ship.position.y-200))
        {
          this.position = new PVector ( (int)random(0, width), (int)random(0, height) );
        }
    this.direction = new PVector ( random(-1, 1), random(-1, 1) );
    this.velocity = direction.copy();
    this.velocity.mult(4);
    radius = 125/2;
    randomAst = (int)random(1,10);
    imgName = "ast" + randomAst + ".png";
    img = loadImage(imgName);
    imageMode(CENTER);
    colliding = false;
    destroyed = false;
    asteroid_depth = 1;
    this.difficulty = dif;
  }
  
  public void Update()
  {
    if(!destroyed)
    {
      this.Wrap();
      position.x += velocity.x;
      position.y += velocity.y;
    }
  }
  
  public void Wrap()
  {
    if(position.x > width+125/2){
      position.x = -125/2;
    }
    else if(position.x < -125/2){
      position.x = width+125/2;
    }
    else if(position.y > height+125/2){
      position.y = -125/2;
    }
    else if(position.y < -125/2){
      position.y = height+125/2;
    }
  }
  
  
  public void Display()
  {
    if(colliding)
    {
      tint(difficulty);
      //ellipse(position.x, position.y, radius*2, radius*2);
      image(img, position.x, position.y);
      //fill(0,0,0);
    }
    else
    {
      tint(difficulty);
      //ellipse(position.x, position.y, radius*2, radius*2);
      image(img, position.x, position.y);
      //fill(0,0,0);
      
    }
  }
}
class Asteroid_Manager {
  
  ArrayList<Asteroid> asteroids;
  ArrayList<Asteroid_Small> smallAsteroids;
  int astNext;
  int diff;
  Asteroid_Manager ()
  {
    asteroids = new ArrayList<Asteroid>();
    smallAsteroids = new ArrayList<Asteroid_Small>();
    astNext = 0;
    
  }
  public void InitializeMode(int mode)
  {
    if( mode == 5 )
    {
      diff = color (35,200,250);
    }
    else if ( mode == 10 )
    {
      diff = color (245,190,61);
    }
    else if ( mode == 15 )
    {
      diff = color (235,122,77);
    }
    else if ( mode == 20 )
    {
      diff = color (242,242,242);
    }
    for ( int i = 0; i < mode; i++ )
    {
      
      asteroids.add(new Asteroid(diff));
    }
  }
  public void DrawAsteroids()
  {
    for ( int i = 0 ; i < asteroids.size(); i++ )
    {
      if(asteroids.get(i).colliding)
      {
        asteroids.remove(i);
      } else {
        asteroids.get(i).Display();
        asteroids.get(i).Update();
      }
    }
  }
  public void SplitAsteroid(PVector posOld, PVector velOld)
  {
    velOld.x = velOld.x*1.5f;
    velOld.y = velOld.y*1.5f;
    Asteroid_Small split1 = new Asteroid_Small(posOld, velOld, 45, diff);
    Asteroid_Small split2 = new Asteroid_Small(posOld, velOld, -45, diff);
    
    smallAsteroids.add(split1);
    smallAsteroids.add(split2);
    
    astNext++;
  }
  public void DrawSmallAsteroids()
  {
    for ( int i = 0 ; i < smallAsteroids.size(); i++ )
    {
      if(smallAsteroids.get(i).colliding)
      {
        smallAsteroids.remove(i);
      } else {
        smallAsteroids.get(i).Display();
        smallAsteroids.get(i).Update();
      }
    }
  }
  
  public void Reset()
  {
    
  }
}
class Asteroid_Small {
  
  PVector position;
  PVector direction;
  PVector velocity;
  float radius;
  int randomAst;
  boolean colliding;
  boolean destroyed;
  String imgName;
  PImage img;
  int mass;
  int asteroid_depth;
  int difficulty;
  
  Asteroid_Small(PVector pos, PVector vel, int ang, int diff)
  {
    // Instantiate vectors and fields
    this.position = pos.copy();
    this.direction = vel.copy();
    this.direction.rotate(radians(ang));
    this.velocity = direction.copy();
    radius = 125/3;
    randomAst = (int)random(1,10);
    imgName = "ast" + randomAst + ".png";
    img = loadImage(imgName);
    img.resize(250/3, 250/3);
    imageMode(CENTER);
    colliding = false;
    destroyed = false;
    asteroid_depth = 2;
    this.difficulty = diff;
  }
  
  public void Update()
  {
    if(!destroyed)
    {
      this.Wrap();
      position.x += velocity.x;
      position.y += velocity.y;
    }
  }
  
  public void Wrap()
  {
    if(position.x > width+125/2){
      position.x = -125/2;
    }
    else if(position.x < -125/2){
      position.x = width+125/2;
    }
    else if(position.y > height+125/2){
      position.y = -125/2;
    }
    else if(position.y < -125/2){
      position.y = height+125/2;
    }
  }
  public void Destroy()
  {
    position.x = -100;
    position.y = -100;
    velocity = new PVector(0,0);
    destroyed = true;
  }
  
  public void Display()
  {
    if(colliding)
    {
      tint(difficulty);
      //ellipse(position.x, position.y, radius*2, radius*2);
      image(img, position.x, position.y);
      //fill(0,0,0);
    }
    else
    {
      tint(difficulty);
      //ellipse(position.x, position.y, radius*2, radius*2);
      image(img, position.x, position.y);
      //fill(0,0,0);
      
    }
  }
}
class Bullet {
  
  PVector velocity;
  PVector position;
  PShape bullet;
  int radius = 5;
  boolean shoot;
  boolean colliding = false;
  int timeout;
  Bullet ()
  {
    this.position = ship.position.copy();
    this.velocity = ship.direction.copy();
    velocity.mult(random(10,13));
    this.shoot = true;
    this.timeout = 240;
    
  }
  
  public void Shoot()
  {
    this.shoot = true;
  }
  
  public void Stop()
  {
    this.shoot = false;
  }
  public void Update()
  {
    position.x += velocity.x;
    position.y += velocity.y;
  }
  public void Display() 
  {
    if(shoot)
    {
      Update();
      ellipse(position.x, position.y, radius, radius);
      timeout--;
    }
  }
}
class Bullet_Manager {
  
  ArrayList<Bullet> bullets;
  Boolean shotFired;

  Bullet_Manager ()
  {
    bullets = new ArrayList<Bullet>();
    shotFired = false;
  }
  
  public void UpdateBullets()
  {
     if( input.isKeyPressed(32) )
      {
        if(!shotFired)
        {
          bullets.add(new Bullet());
          shotFired = true;
        }
      } 
      else if ( input.isKeyReleased(32) ) 
      {
        if(shotFired)
        {
          shotFired = false;
        }
      }
  }
  public void DrawBullets()
  {
    for ( int i = 0 ; i < bullets.size(); i++ )
    {
      if(bullets.get(i).colliding)
      {
        bullets.remove(i);
      }
      else if(bullets.get(i).timeout <= 0)
      {
        bullets.remove(i);
      } else {
        bullets.get(i).Display();
      }
    }
  }
}
class CollisionManager
{
  int i = 0;
  int j = 0;
  CollisionManager()
  {
    
  }
  
  public void HandleShipCollisions()
  {
    
    for ( int k = 0; k < astManager.asteroids.size(); k++ ) 
    {
      if ( astManager.asteroids.get(k) == null )
      {
      } else {
        float distance = dist(astManager.asteroids.get(k).position.x, 
                              astManager.asteroids.get(k).position.y, 
                              ship.position.x, ship.position.y);
        float rads = astManager.asteroids.get(k).radius + ship. radius;
        
        if ( rads > distance )
        {
          ship.Ship_Death();
        } else {
          astManager.asteroids.get(k).colliding = false;
        }
      }
    }
  }
  
  public void HandleBulletCollisions()
  {
    for ( i = 0; i < astManager.asteroids.size(); i++ )
    {
      for ( j = 0; j < bul.bullets.size(); j++ )
        {
          if( astManager.asteroids.size() == 0 )
          {
          }
          else if ( bul.bullets.get(j) == null || astManager.asteroids.get(i) == null )
          {
          }
          else {
            float bulDist = dist(astManager.asteroids.get(i).position.x,
                                 astManager.asteroids.get(i).position.y, 
                                 bul.bullets.get(j).position.x, 
                                 bul.bullets.get(j).position.y);
            float bulRads = astManager.asteroids.get(i).radius + bul.bullets.get(j).radius;
            if ( bulRads > bulDist )
            {
              astManager.SplitAsteroid(astManager.asteroids.get(i).position, astManager.asteroids.get(i).velocity);
              astManager.asteroids.get(i).colliding = true;
              score = score + ( 25 * level );
              bul.bullets.remove(j);
              
              //ast = null;
              
            } else {
              //astManager.asteroids.get(i).colliding = false;
            }
          }
        }
    }
  }
   
  public void HandleSmallAsteroidCollisions()
  {
    
    for ( Asteroid_Small ast : astManager.smallAsteroids ) 
    {
      if ( ast == null )
      {
      } else {
        float distance = dist(ast.position.x, ast.position.y, ship.position.x, ship.position.y);
        float rads = ast.radius + ship. radius;
        
        if ( rads > distance )
        {
          ship.Ship_Death();
        } else {
          ast.colliding = false;
        }
      }
    }
  }
  public void HandleSmallBulletCollisions()
  {
    for ( j = 0; j < bul.bullets.size(); j++ )
    {
      for ( i = 0; i < astManager.smallAsteroids.size(); i++ )
        {
          if( astManager.smallAsteroids.size() == 0 || bul.bullets.size() == 0 )
          {
          }
          else if ( bul.bullets.get(j) == null || astManager.smallAsteroids.get(i) == null )
          {
          }
          else {
            float bulDist = dist(astManager.smallAsteroids.get(i).position.x,
                                 astManager.smallAsteroids.get(i).position.y, 
                                 bul.bullets.get(j).position.x, 
                                 bul.bullets.get(j).position.y);
            float bulRads = astManager.smallAsteroids.get(i).radius + bul.bullets.get(j).radius;
            if ( bulRads > bulDist )
            {
              astManager.smallAsteroids.get(i).colliding = true;
              bul.bullets.get(j).colliding = true;
              score = score + ( 50 * level );
            } else {
              
            }
          }
       }
    }
  }
}
class DeathMenu
{
  boolean display;
  PVector playAgainTop;
  PVector playAgainBottom;
  DeathMenu()
  {
    display = false;
    score = 0;
    this.playAgainTop = new PVector(250, 550);
    this.playAgainBottom = new PVector(750, 603);
  }
  
  public void Display()
  {
    image(background, width/2 ,height/2);
    tint(255,255,255);
    text("Your Score:", 500, 400);
    text(score, 500, 500);
    text("Click here to play again!", 500, 600);
  }
  public void CheckClick()
  {
    if(mouseX > playAgainTop.x && mouseX < playAgainBottom.x
      && mouseY > playAgainTop.y && mouseY < playAgainBottom.y)
      {
        menu.main.reset();
        this.display = false;
      }
  }
}
//-----------------------------------------------------------------------------
//class InputManager
//Checks the first 256 ASCII coded keys for a key press
//If any of those keys are pressed, the array with index of the key's ASCII code will be true.
//If a key is not pressed, the array at the index of the key's ASCII code will be false. 
//Call inputManagerObject.recordKeyPress(keyCode); inside of the keyPressed event listener
//Call inputManagerObject.recordKeyRelease(keyCode); inside of the keyReleased event listener
//To check if a key is pressed, create an instance of this class in the main program.
//Call the isKeyPressed() function on this InputManager object, passing in the integer value or character of the key 
//For example, if (inputManagerObject.isKeyPressed(32)) { ... } checks if the space bar is pressed
//Processing will inplicitly cast a character to an integer. 
//-----------------------------------------------------------------------------


class InputManager {
  boolean[] keys;

  InputManager() {
    keys = new boolean[256];
  }

  public void recordKeyPress(int k) {
    keys[k] = true;
  }

  public void recordKeyRelease(int k) {
    keys[k] = false;
  }

  public boolean isKeyPressed(int k) {
    return keys[k];
  }

  public boolean isKeyReleased(int k) {
    return !keys[k];
  }
}
class MainMenu
{
  boolean display;
  boolean muted = false;
  PVector topCornerEasy;
  PVector bottomCornerEasy;
  PVector topCornerHard;
  PVector bottomCornerHard;
  PVector topCornerReallyHard;
  PVector bottomCornerReallyHard;
  PVector topCornerComputer;
  PVector bottomCornerComputer;
  PVector topQuit;
  PVector bottomQuit;
  PVector topMute;
  PVector bottomMute;

  MainMenu()
  {
    imageMode(CENTER);
    display = true;
    textSize(32);
    textAlign(CENTER);
    PFont font = loadFont("Dialog.plain-48.vlw");
    textFont(font);
    topCornerEasy = new PVector(350, 400-45);
    bottomCornerEasy = new PVector(650, 403);
    topCornerHard = new PVector(350,500-45);
    bottomCornerHard = new PVector(650, 503);
    topCornerReallyHard = new PVector(300,600-45);
    bottomCornerReallyHard = new PVector(700, 603);
    topCornerComputer = new PVector(300, 700-45);
    bottomCornerComputer = new PVector(700, 703);
    topQuit = new PVector(50, 900-45);
    bottomQuit = new PVector(150, 903);
    topMute = new PVector(800, 900-45);
    bottomMute = new PVector(950, 903);
  }
  
  public void Display()
  {
    image(background, width/2 ,height/2);
    tint(255,255,255);
    textSize(72);
    text("Asteroids for Computers", 500, 150);
    textSize(32);
    text("Seriously, it's hard", 500, 200);
    textSize(48);
    text("Easy Mode", 500, 400);
    text("Hard Mode", 500, 500);
    text("Really Hard Mode", 500, 600);
    text("Computer Mode", 500, 700);
    text("Quit", 100, 900);
    if(!muted)
    {
      text("Mute Music", 850, 900);
    } else {
      text("Unmute", 850, 900);
    }
  }
  public void CheckClick()
  {
    if(mouseX > topCornerHard.x && mouseX < bottomCornerHard.x
      && mouseY > topCornerHard.y && mouseY < bottomCornerHard.y)
      {
        mode = 10;
        this.display = false;
        astManager.InitializeMode(mode);
      }
    else if ( mouseX > topCornerReallyHard.x && mouseX < bottomCornerReallyHard.x
          && mouseY > topCornerReallyHard.y && mouseY < bottomCornerReallyHard.y)
          {
            mode = 15;
            this.display = false;
            astManager.InitializeMode(mode);
          }
    else if ( mouseX > topCornerComputer.x && mouseX < bottomCornerComputer.x
          && mouseY > topCornerComputer.y && mouseY < bottomCornerComputer.y)
          {
            mode = 20;
            this.display = false;
            astManager.InitializeMode(mode);
          }
    else if (mouseX > topCornerEasy.x && mouseX < bottomCornerEasy.x
          && mouseY > topCornerEasy.y && mouseY < bottomCornerEasy.y)
          {
            mode = 5;
            this.display = false;
            astManager.InitializeMode(mode);
          }
    else if (mouseX > topQuit.x && mouseX < bottomQuit.x
          && mouseY > topQuit.y && mouseY < bottomQuit.y)
          {
            exit();
          }
    else if (mouseX > topMute.x && mouseX < bottomMute.x
          && mouseY > topMute.y && mouseY < bottomMute.y)
          {
            if(!muted)
            {
              player.setGain(-100);
              muted = true;
            } else {
              player.setGain(-15);
              muted = false;
            }
          }
  } 
  public void reset()
  {
    this.display = true;
    ship = new Ship();
    score = 0;
    astManager = new Asteroid_Manager();
  }
}
class Menu
{
  
  MainMenu main;
  PauseMenu pause;
  DeathMenu death;
  
  Menu()
  {
    main = new MainMenu();
    pause = new PauseMenu();
    death = new DeathMenu();
  }
  
  public boolean Display()
  {
    if(main.display)
    {
      main.Display();
      return false;
    }
    else if (pause.display)
    {
      pause.Display();
      return false;
    }
    else if (death.display)
    {
      death.Display();
      return false;
    }
    else
    {
      return true;
    }
  }
  public void HandleMouseClick()
  {
    if(main.display)
    {
      main.CheckClick();
    }
    else if(pause.display)
    {
      pause.CheckClick();
    }
    else if(death.display)
    {
      death.CheckClick();
    }
  }
  public void DeathScreen()
  {
    death.display = true;
  }
  public void MainScreen()
  {
    main.display = true;
  }
}
class PauseMenu
{
  boolean display;
  boolean muted = false;
  
  PVector topMain;
  PVector bottomMain;
  
  PVector topQuit;
  PVector bottomQuit;
  
  PVector topMute;
  PVector bottomMute;

  PauseMenu()
  {
    display = false;
    this.topQuit = new PVector(50, 900-45);
    this.topMain = new PVector( 350, 900-45);
    this.bottomMain = new PVector( 650, 903);
    this.bottomQuit = new PVector(150, 903);
    this.topMute = new PVector(800, 900-45);
    this.bottomMute = new PVector(950, 903);
    
  }
  
  public void Display()
  {
    tint(255,255,255);
    image(background, width/2 ,height/2);
    textSize(24);
    text("Credits", 500, 300);
    text("Song: Trance Game Limiter", 500, 450);
    text("by Tristan Demetri (Vector Project)", 500, 525);
    text("Image: Stars Space Wallpaper", 500, 600);
    text("http://krswallpaper.com/widescreens/stars-space-wallpaper-", 500,650);
    text("fullscreen.html/stars-space-wallpaper-fullscreen", 500, 700);
    textSize(48);
    text("Main Menu", 500, 900);
    text("Quit", 100, 900);
    if(!muted)
    {
      text("Mute Music", 850, 900);
    } else {
      text("Unmute", 850, 900);
    }
    
  }
  
  public void CheckClick()
  {
    if (mouseX > topMain.x && mouseX < bottomMain.x
        && mouseY > topMain.y && mouseY < bottomMain.y)
        {
          menu.main.reset();
          this.display = false;
        }
    if (mouseX > topQuit.x && mouseX < bottomQuit.x
          && mouseY > topQuit.y && mouseY < bottomQuit.y)
          {
            exit();
          }
    else if (mouseX > topMute.x && mouseX < bottomMute.x
          && mouseY > topMute.y && mouseY < bottomMute.y)
          {
            if(!muted)
            {
              player.setGain(-100);
              muted = true;
            } else {
              player.setGain(-15);
              muted = false;
            }
          }
  }
  public void Pause()
  {
    
    
      if (display)
      {
        display = false;
      } else {
        display = true;
      }
   
  }
}
class Ship
{
  
  PVector position;
  PVector direction;
  PVector velocity;
  PVector acceleration;
  float speed;
  float maxSpeed;
  float radius;
  PShape shipModel;
  boolean accelerate = false;
  boolean turnLeft = false;
  boolean turnRight = false;
  boolean cannotCollide = false;
  int invTimer = 4*60;
  int lives = 2;
  PImage sheild;
  boolean fliker;
  Ship()
  {
    this.position = new PVector(width/2, height/2);
    this.velocity = new PVector(0, 0);
    this.direction = new PVector(1,0);
    this.acceleration = new PVector(0,0);
    this.radius = 15;
    
    this.shipModel = createShape();
    shipModel.beginShape();
    shipModel.fill(255,255,255);
    shipModel.vertex(20,0);
    shipModel.vertex(-20,-10);
    shipModel.vertex(-20,10);
    shipModel.endShape();
    this.sheild = loadImage("sheild.png");
    sheild.resize(75,75);
    this.fliker = true;
  }
  
  public void Turn()
  {
  // When arrow keys are pressed, rotate direction
    if(input.keys[LEFT])
    {
      turnLeft = true;
    }
    else if(input.keys[RIGHT])
    {
      turnRight = true;
    }
    else if(input.keys[UP])
    {
      accelerate = true;
    }
  }
  
  public void Deccelerate()
  {
    if(!input.keys[UP])
    {
      accelerate = false;
    }
  }
  public void StopTurning()
  {
    if(!input.keys[LEFT])
    {
      turnLeft = false;
    }
    if(!input.keys[RIGHT])
    {
      turnRight = false;
    }
  }
  
  public void Wrap()
  {
    if(position.x > width){
      position.x = 0;
    }
    else if(position.x < 0){
      position.x = width;
    }
    else if(position.y > height){
      position.y = 0;
    }
    else if(position.y < 0){
      position.y = height;
    }
  }
  
  public void Update()
  {
    // Move the ship's position using acceleration, velocity, position here!
    this.Wrap();
    if(!accelerate)
    {
      acceleration.mult(.94f);
    } else {
      acceleration.add(.25f,.25f);
    }
    
    if(turnLeft)
    {
      direction.rotate(radians(-6));
    }
    if(turnRight)
    {
      direction.rotate(radians(6 ));
    }
    if(cannotCollide)
    {
      if(invTimer > 0)
      {
        invTimer--;
      } else {
        cannotCollide = false;
        invTimer = 240;
      }
    }
    velocity.x = direction.x*acceleration.x;
    velocity.y = direction.y*acceleration.y;
    this.velocity.limit(7);
      position.x += velocity.x;
      position.y += velocity.y;
   
    
  }
  
  public void Display()
  {
    if(invTimer % 10 == 0)
    {
      if(fliker)
      {
        fliker = false;
      } else {
        fliker = true;
      }
    }
    pushMatrix();
      
      translate(position.x, position.y);
      rotate(direction.heading());
      if(cannotCollide)
      {
        if(fliker)
        {
          tint(255,255,255);
          image(sheild, 0, 0);
        }
      }
      shape(shipModel, 0,0);
      stroke(0);
    popMatrix();
    for( int i = 0; i < lives; i++)
    {
      pushMatrix();
        translate(50+i*30, 100);
        rotate(radians(-90));
        shape(shipModel,0,0);
      popMatrix();
    }
    
    
   
  }
  public void Ship_Death()
  {
    if( lives > 0 && !cannotCollide)
    {
    this.position = new PVector(width/2, height/2);
    this.velocity = new PVector(0, 0);
    this.direction = new PVector(1,0);
    this.acceleration = new PVector(0,0);
    lives--;
    cannotCollide = true;
    } else if (lives == 0 && !cannotCollide) {
      //goto end screen
      menu.DeathScreen();
    }
  }
}
  public void settings() {  size(1000,1000); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Katcher_Asteroids" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
